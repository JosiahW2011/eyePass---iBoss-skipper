let submitIP = document.getElementById('submitIP');
let resetIP = document.getElementById('resetIP');
let update = document.getElementById('update');

let mainIP = "";
let host = "";
let port = "";

document.addEventListener("DOMContentLoaded", function() {
	fetch("https://api.ipify.org/?format=json")
		.then(response => response.json())
		.then(data => {
			mainIP = data.ip;
		})
		.catch(error => {
			console.error('Error fetching IP address: ', error);
		});
})

resetIP.addEventListener('click', function() {
	host = mainIP;
	port = "8080";
	update.innerHTML = '<span style="color: #00ff00;">Reset IP to: ' + mainIP + '</span><br/>Please note that this is your public IP btw.';
});

submitIP.addEventListener('click', function() {
	var temporaryHost = prompt('Insert IP:');
	var temporaryPort = prompt('Insert Port:');

	host = temporaryHost;
	port = temporaryPort;

	if (host === mainIP) {
		alert("You can't use your old IP, good try though!");
		update.innerHTML = '<span style="color: #ff0000;">Tried to use old host.</span>';
		return;
	} else {
		if (host === "" || port === "") {
			alert('Host and Port must not be empty.');
			update.innerHTML = '<span style="color: #ff0000;">Host or Port is empty.</span>';
			return;
		} else {
			alert('Successful operation!');
			update.innerHTML = '<span style="color: #00ff00;">Set host to ' +  host + '<br/>and ' + 'port to ' + port + '.</span>';
			return;
		}
	}
});

const pacScript = `
function FindProxyForURL(url,host) {
	if (host.includes("https://google.com/")) {
		return "PROXY ${host}:${port}"
	}

	return "DIRECT";
}
`;

chrome.proxy.settings.set(
	{
		value: {
			mode: "pac_script",
			pacScript: {
				data: pacScript
			}
		},
		scope: 'regular'
	},
	function() {
		console.log("PAC script applied to Chrome Settings...")
	}
);